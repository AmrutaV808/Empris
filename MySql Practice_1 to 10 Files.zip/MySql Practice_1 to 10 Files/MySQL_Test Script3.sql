select * from test1;
update test1 set id =3 where NAME = 'Amruta';
update test1 set name = 'Test Name1',address = 'Test Address1' where id = 1;
Insert into test1 (id,name,address) values (4,'Test4','Test address4'), (5,'Test5','Test address5');
update test1 set name='Test Name2', address = 'Test Address2' where id= 2;
update test1 set name = 'Test Name3', address = 'Test Address3' where id = 3;
update test1 set name = 'Test Name4' where id = 4;
alter table test1 add phonenumber int(10);
update test1 set phonenumber = '12345' where id =1;