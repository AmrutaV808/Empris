Select * from test1;
select * from test1 where name not like 'T%';
select * from test1 where name like '%5';
select * from test1 where name like '%a';
select * from test1 where name like 'a%';
select * from test1 where address regexp 'test+';
select * from test1 where address regexp 'tes*';
select * from test1 where address regexp 'test?';
select * from test1 where address regexp '[p]';
select * from test1 where address regexp '^[te]';
select * from test1 where address regexp '4[[:>	:]]';

Create table dept (dept_id INT(5), dept_name varchar(50));
select * from dept;
insert into dept (dept_id, dept_name) value (001,'FInance');
insert into dept (dept_id, dept_name) value (002,'HR');
insert into dept (dept_id, dept_name) value (003,'IT');
Drop table dept;


select * from employee_details;
select * from dept_details;

insert into dept_details (dept_id, dept_name) value (001,'Finance');
insert into dept_details (dept_id, dept_name) value (002,'HR');
insert into dept_details (dept_id, dept_name) value (003,'IT');

alter table employee_details add column dept_id int(5);

update employee_details set dept_id = '1' where id=1;
update employee_details set dept_id = '2' where id=2;
update employee_details set dept_id = '3' where id=3;
update employee_details set dept_id = '4' where id=4;
update employee_details set dept_id = '2' where id=5;
update employee_details set dept_id = '3' where id=6;

show columns from employee_details;

rename table employee_details to emp_details;

select * from emp_details;
show columns from emp_details;
alter table emp_details change column id  emp_id int(11) not null;
alter table emp_details modify emp_id int(10) not null;
alter table emp_details add address1 varchar(50) after address;

select * from emp_details limit 2;
select * from emp_details limit 3, 1;

select emp_id, name,dept_id from emp_details where dept_id = (select dept_id from dept_details where dept_id <2);
