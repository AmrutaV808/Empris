use test;
create table test1 (id int);
insert into test1 value (1);
select * from test1;
insert into test1 value (2);
select * from test1;