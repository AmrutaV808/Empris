Select * from test1;
select * from test1 where name not like 'T%';
select * from test1 where name like '%5';
select * from test1 where name like '%a';
select * from test1 where name like 'a%';
select * from test1 where address regexp 'test+';
select * from test1 where address regexp 'tes*';
select * from test1 where address regexp 'test?';
select * from test1 where address regexp '[p]';
select * from test1 where address regexp '^[te]';
select * from test1 where address regexp '4[[:>	:]]';

Create table dept (dept_id INT(5), dept_name varchar(50));
select * from dept;
insert into dept (dept_id, dept_name) value (001,'FInance');
insert into dept (dept_id, dept_name) value (002,'HR');
insert into dept (dept_id, dept_name) value (003,'IT');
Drop table dept;


select * from employee_details;
select * from dept_details;

insert into dept_details (dept_id, dept_name) value (001,'Finance');
insert into dept_details (dept_id, dept_name) value (002,'HR');
insert into dept_details (dept_id, dept_name) value (003,'IT');
